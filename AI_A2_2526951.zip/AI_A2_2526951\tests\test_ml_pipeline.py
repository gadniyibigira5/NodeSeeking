"""ML integrity: no leakage, artifacts load, split is deterministic."""
from __future__ import annotations

import joblib
import pytest

from src.schema import (
    FEATURE_COLS,
    LEAKY_COLUMNS,
    check_no_leakage,
)


def test_features_contain_no_targets():
    bad = set(FEATURE_COLS) & LEAKY_COLUMNS
    assert not bad, f"Leaky features detected: {bad}"


def test_check_no_leakage_raises():
    from src.schema import SchemaError
    with pytest.raises(SchemaError):
        check_no_leakage(["rainfall_mm", "yield_tons"])


def test_saved_models_load():
    from pathlib import Path
    model_dir = Path(__file__).resolve().parent.parent / "models"
    for name in [
        "regression_preprocessor.joblib", "regression_model.joblib",
        "classification_preprocessor.joblib", "classification_model.joblib",
        "clustering_preprocessor.joblib", "clustering_model.joblib",
    ]:
        p = model_dir / name
        assert p.exists(), f"Missing model: {name}"
        joblib.load(p)   # raises on corruption


def test_split_is_deterministic():
    from src.prepare import audit_and_prepare
    a = audit_and_prepare()
    b = audit_and_prepare()
    assert list(a["test_index"]) == list(b["test_index"])
    assert len(a["X_tr"]) == len(b["X_tr"])