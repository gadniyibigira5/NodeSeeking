# Demo Video Script (target 5 minutes)

Pre-recording checklist:
- Handwritten card: Gad Niyibigira / 25/26951 / AI-A2-6951
- Terminal font size 16+ (readable at 100 percent zoom)
- git log --oneline -1 shows final commit hash
- Close all extra windows

Sequence:

0:00-0:15 Identity card
Hold handwritten card to camera. Show full name, registration 25/26951,
verification code AI-A2-6951. Say: "I am Gad Niyibigira, registration
25/26951, verifying this submission as AI-A2-6951."

0:15-0:30 Commit hash
Run: git log --oneline -1
Run: git rev-parse HEAD
Read the hash aloud.

0:30-1:15 Full reproduction
Run: python run_all.py --student-id ug2526951@ines.ac.rw --seed 6951
While it runs: "Data regenerated, models retrained." Wait for DONE.
Point at fingerprint a0e540df... and say "Reproducible."

1:15-2:00 Open artifacts and interpret
Open artifacts/regression_metrics.json in Notepad. Read selected_model and
selection_reason. Explain from memory: "Ridge had the lowest test MAE of
0.3385 vs the baseline's 1.5400. RandomForest underperformed because the
generator uses an additive linear yield formula, so the correctly-specified
model class is linear."
Open artifacts/plots/residuals.png. Say: "Residuals centered on zero, no
structure, consistent with a correctly specified linear model."

2:00-2:45 CLI valid and invalid
Run: python predict.py --json samples/valid.json
Read aloud: "yield 6.6 tons, high_risk 0, probability 0.097, cluster 4."
Run: python predict.py --json samples/invalid.json
Point at error: "Rainfall 5000 rejected against range 600 to 1400."

2:45-3:45 FastAPI
Start: uvicorn app:app --host 127.0.0.1 --port 8000
Open http://127.0.0.1:8000/docs in browser. Show three endpoints.
Call /health. Read verification code aloud.
Call /model-info. Show model names.
Call /predict with samples/valid.json. Read prediction.
Call /predict with rainfall_mm=5000 record. Show the 422.

3:45-4:15 Tests
Stop uvicorn (Ctrl+C). Run: pytest -q
Show 21 passed. Say: "These cover valid and invalid paths - schema, CLI, API,
reproducibility, leakage guards, split determinism."

4:15-4:45 Report and declaration
Open docs/AI_A2_2526951_REPORT.pdf. Show pages 1, 4, 5, 6.
Open evidence/DECLARATION.pdf. Show signed page.

4:45-5:00 Terminal clock and close
Run: Get-Date
Say: "Recorded 19 October 2026, before the 5 PM CAT deadline. End of demo."