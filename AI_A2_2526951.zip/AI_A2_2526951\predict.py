"""
CLI prediction entry point.

Usage:
  python predict.py --json samples/valid.json
  python predict.py --json samples/invalid.json

Loads all saved artifacts, validates the record against src.schema,
and returns regression, classification and cluster assignment.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from src.schema import (
    FEATURE_COLS,
    RANGE_RULES,
    SchemaError,
    validate_record,
)

MODEL_DIR = Path(__file__).resolve().parent / "models"
VERIFICATION_CODE = "AI-A2-6951"


def _load(name):
    p = MODEL_DIR / name
    if not p.exists():
        raise SystemExit(
            f"[{VERIFICATION_CODE}] Missing model artifact {p}. "
            f"Run 'python run_all.py' first."
        )
    return joblib.load(p)


def _record_to_frame(record):
    return pd.DataFrame([{c: record[c] for c in FEATURE_COLS}])


def predict_one(record):
    result = validate_record(record)
    if not result.ok:
        raise SchemaError("; ".join(result.errors))

    X = _record_to_frame(record)

    reg_pre = _load("regression_preprocessor.joblib")
    reg_mod = _load("regression_model.joblib")
    clf_pre = _load("classification_preprocessor.joblib")
    clf_mod = _load("classification_model.joblib")
    clu_pre = _load("clustering_preprocessor.joblib")
    clu_mod = _load("clustering_model.joblib")

    yield_pred = float(reg_mod.predict(reg_pre.transform(X))[0])

    if hasattr(clf_mod, "predict_proba"):
        proba = float(clf_mod.predict_proba(clf_pre.transform(X))[0, 1])
    else:
        proba = float(clf_mod.decision_function(clf_pre.transform(X))[0])
    risk_pred = int(proba >= 0.5)

    cluster = int(clu_mod.predict(clu_pre.transform(X))[0])

    return {
        "verification_code": VERIFICATION_CODE,
        "prediction": {
            "yield_tons": round(yield_pred, 3),
            "high_risk": risk_pred,
            "high_risk_probability": round(proba, 4),
            "cluster": cluster,
        },
        "input": record,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", required=True, help="Path to a JSON record file")
    args = parser.parse_args()

    path = Path(args.json)
    if not path.exists():
        print(f"[{VERIFICATION_CODE}] ERROR: file not found: {path}", file=sys.stderr)
        sys.exit(2)

    try:
        record = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        print(f"[{VERIFICATION_CODE}] ERROR: invalid JSON in {path}: {e}", file=sys.stderr)
        sys.exit(2)

    try:
        out = predict_one(record)
    except SchemaError as e:
        print(f"[{VERIFICATION_CODE}] VALIDATION ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()