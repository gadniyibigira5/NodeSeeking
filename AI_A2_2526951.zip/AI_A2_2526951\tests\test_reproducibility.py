"""Reproducibility: the dataset must regenerate to the known fingerprint."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATASET = ROOT / "data" / "AI_A2_2526951.csv"


def _sha256(path):
    h = hashlib.sha256()
    h.update(Path(path).read_bytes())
    return h.hexdigest()


def test_fingerprint_matches_known(known_fingerprint):
    assert DATASET.exists(), "Dataset missing"
    assert _sha256(DATASET) == known_fingerprint


def test_regeneration_reproduces_fingerprint(known_fingerprint):
    result = subprocess.run(
        [sys.executable, "data/generate_data.py",
         "--student-id", "ug2526951@ines.ac.rw", "--seed", "6951"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 0, f"stderr: {result.stderr}"
    assert _sha256(DATASET) == known_fingerprint


def test_meta_json_agrees_with_fingerprint(known_fingerprint):
    meta_path = DATASET.with_suffix(".meta.json")
    meta = json.loads(meta_path.read_text())
    assert meta["sha256"] == known_fingerprint
    assert meta["verification_code"] == "AI-A2-6951"