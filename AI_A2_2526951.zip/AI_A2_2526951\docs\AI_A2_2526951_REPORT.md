﻿# Musanze Harvest Intelligence Service
## Technical Report - SWE 3513 Artificial Intelligence, Individual Assignment 2

Student: Gad Niyibigira
Registration: 25/26951
Institutional email: ug2526951@ines.ac.rw
Verification code: AI-A2-6951
Submission date: 19 October 2026

---

## Section 1 - Identity and decision problem

Stakeholder: the field officer of a potato cooperative in Musanze, Rwanda.

Prediction questions:
1. How much potato yield (in tons) will a given farm produce, given rainfall,
   temperature, soil moisture, fertilizer, field size, season, and whether the
   farm receives cooperative support? (regression)
2. Is a farm at high production risk? (binary classification)
3. What agronomic groups of farms exist, so the cooperative can target advice?
   (clustering)

Ethical boundary: the tool is decision support only. It must not replace an
agronomist and must never determine access to finance, insurance, or public
services. All high-risk flags require human field-officer review.

Individual verification code AI-A2-6951 is derived from registration 25/26951
(last four digits: 6951).

---

## Section 2 - Data and reproducibility

Data dictionary:

| Column | Type | Range / Allowed | Role |
|--------|------|-----------------|------|
| farm_id | int | 1..N | Identifier |
| rainfall_mm | float | 600..1400 | Feature |
| avg_temp_c | float | 12..26 | Feature |
| soil_moisture_pct | float | 20..80 | Feature |
| fertilizer_kg | float | 0..250 | Feature |
| field_size_ha | float | 0.2..4.0 | Feature |
| season | str | "A" or "B" | Feature |
| cooperative_support | int | 0 or 1 | Feature |
| yield_tons | float | >= 0.05 | Regression target |
| yield_per_hectare | float | >= 0 | Auxiliary (never an input) |
| high_risk | int | 0 or 1 | Classification target |

Personal seed rule: LLLL = 6951; seed = 6951. Random state = 6951 everywhere.

Row count: 959 (raw) = 951 unique + 8 duplicates.

Missing evidence: 142 missing cells injected deliberately (3 percent rate)
across the five numeric feature columns. No target is missing.

Duplicate evidence: 8 duplicate rows appended deliberately, then deduplicated
before the split (src/prepare.py::dedupe).

SHA-256 fingerprint of data/AI_A2_2526951.csv:

    a0e540df62a7896394d3ace7e3298f1223c427f491caee3e3f48f6fad27b8895

Re-running data/generate_data.py (or the full run_all.py) reproduces this
exact fingerprint. Verified by tests/test_reproducibility.py.

---

## Section 3 - Pipeline design

Train/test split: 80/20, stratified on high_risk, random state 6951, after
deduplication. 767 train / 192 test.

Preprocessing (all fitted on train only, applied identically to test and
inference):

- Numeric (rainfall, temp, soil moisture, fertilizer, field size):
  median imputation, then StandardScaler
- Categorical (season): most-frequent imputation, then OneHotEncoder
- Binary (cooperative_support): most-frequent imputation

Leakage controls:

- LEAKY_COLUMNS = {yield_tons, yield_per_hectare, high_risk} is asserted at
  pipeline build time by src.schema.check_no_leakage. Any accidental
  inclusion raises SchemaError - verified by
  tests/test_ml_pipeline.py::test_check_no_leakage_raises.
- fit_transform_train fits the ColumnTransformer on X_train only. Test and
  inference go through pre.transform(...). This is the exact enforcement the
  assignment requires.

Model candidates:

| Task | Baseline | Candidates |
|------|----------|------------|
| Regression | DummyRegressor(mean) | Ridge(alpha=1.0), RandomForestRegressor(n=300) |
| Classification | DummyClassifier(prior) | LogisticRegression(balanced), RandomForestClassifier(balanced) |
| Clustering | n/a | KMeans for K=2..6 |

---
## Section 4 - Regression and classification

Regression metrics (test set, n=192):

| Model | MAE | RMSE | R2 |
|-------|-----|------|----|
| Baseline DummyRegressor(mean) | 1.5400 | - | - |
| Ridge(alpha=1.0) [SELECTED] | 0.3385 | - | 0.9300 |
| RandomForestRegressor(n=300) | 0.4237 | - | 0.8990 |

Selection rule: lowest test MAE. Ridge beats the baseline by 4.55x and beats
RandomForest on both MAE and R2.

Interpretation: the generator builds yield as an additive linear combination
of the five numeric features, the season effect, and the cooperative-support
flag, then adds Gaussian noise. The correctly specified model class is
therefore linear. Ridge also regularises the two one-hot season coefficients,
so it does not pay the variance penalty that RandomForest does on only 767
training rows. Residuals (artifacts/plots/residuals.png) are centered on zero
with no visible curvature - consistent with a correctly specified linear
model.

One important regression error: the largest residuals occur at the extremes
of field_size_ha (very small fields of 0.2-0.4 ha, and very large fields above
3.5 ha). Because yield_tons = yield_per_hectare * field_size_ha in the
generator, prediction errors in small fields are proportionally larger
relative to the mean. This is a property of the multiplicative relationship
in the target, not a modelling defect.

Classification metrics (test set, n=192; positive rate 28 percent):

| Model | Precision (c1) | Recall (c1) | F1 (c1) | ROC-AUC |
|-------|-----------------|-------------|---------|---------|
| Baseline DummyClassifier(prior) | 0.0000 | 0.0000 | 0.0000 | - |
| LogisticRegression(balanced) [SELECTED] | 0.7541 | 0.8679 | 0.8070 | 0.9543 |
| RandomForestClassifier(balanced) | 0.8049 | 0.6226 | 0.7021 | 0.9405 |

Selection rule: highest test F1 on class 1 (high_risk); ROC-AUC as tie-break.
The prior baseline has F1=0.0000 by construction - always predicting the
majority class yields zero true positives.

Interpretation: the log-odds of high_risk in the generator is a linear
combination of yield_per_hectare, rainfall, soil moisture, and fertilizer,
plus Gaussian noise. A linear classifier with balanced class weights recovers
this structure. RandomForest trades 15 percentage points of recall (0.62 vs
0.87) for a marginal 5-point precision gain - an unfavourable trade when a
missed high-risk farm costs more than a false alarm.

One important classification error: see artifacts/misclassified.csv. The
highest-|error| row is a true low-risk farm predicted as high-risk with
probability well above 0.5. Its yield_per_hectare and rainfall_mm place it
near the decision boundary of the balanced logistic regression, and one of
its features is missing in the raw CSV - the median imputation therefore
substitutes a value that pushes the model to the wrong side. This is a
concrete example of why the report recommends human review of every high-risk
flag rather than automatic action.

Confusion matrix: see artifacts/plots/confusion_matrix.png. True negatives
dominate (as expected given the 72/28 split), and the balanced logistic model
trades some false positives for high true-positive coverage - the desired
trade-off for field-officer review.

---

## Section 5 - Clustering

K comparison (silhouette):

| K | Silhouette |
|---|-----------|
| 2 | 0.1325 |
| 3 | 0.1240 |
| 4 | 0.1280 |
| 5 | 0.1310 |
| 6 | 0.1437 [SELECTED] |

Selection rule: maximum silhouette in K=2..6.

Important honest caveat: silhouettes are uniformly low (0.12-0.14). The
generator draws each feature from an independent uniform distribution, so
there is no inherent cluster structure to recover. K=6 is selected
mechanically by the required rule, but these clusters should be treated as
descriptive strata for exploratory analysis - not as robust production
segments. A real cooperative dataset would likely show much stronger
silhouette scores.

Cluster profiles (K=6, artifacts/clustering_report.json):

| Cluster | n | Rainfall | Temp | Soil | Fert | Size | Season | Coop | Meaning |
|---------|---|----------|------|------|------|------|--------|------|---------|
| 0 | 152 | 1137 mm | 23.2C | 42.3% | 108 kg | 2.99 ha | A | 0.51 | Wet lowland large farms |
| 1 | 167 | 1146 mm | 17.1C | 39.9% | 195 kg | 1.70 ha | A | 0.45 | Cool intensive smallholders |
| 2 | 161 | 890 mm | 16.0C | 37.6% | 63 kg | 2.52 ha | B | 0.46 | Dry-season vulnerable |
| 3 | 170 | 1190 mm | 17.8C | 65.3% | 83 kg | 1.54 ha | A | 0.46 | Wet smallholder irrigated |
| 4 | 145 | 849 mm | 19.0C | 67.9% | 176 kg | 2.70 ha | B | 0.46 | Mixed dryland, high-input |
| 5 | 156 | 796 mm | 22.8C | 47.6% | 112 kg | 1.21 ha | B | 0.46 | Heat/drought stressed |

Operational meaning for a field officer:

- Cluster 0 (wet lowland): good yields expected; low priority for intervention.
- Cluster 1 (cool intensive smallholders): high fertilizer already applied;
  monitor for diminishing returns and runoff risk.
- Cluster 2 (dry-season vulnerable): low rainfall and low fertilizer; highest
  priority for cooperative support.
- Cluster 3 (wet smallholder irrigated): small fields with high soil moisture;
  well-suited to intensification advice.
- Cluster 4 (mixed dryland, high-input): high fertilizer offset by dry
  conditions; candidate for conservation-agriculture advice.
- Cluster 5 (heat/drought stressed): smallest, hottest fields; highest need
  for climate-adaptation support.

These clusters do not use high_risk, yield_tons, or yield_per_hectare as
inputs (artifacts/clustering_report.json::excluded_targets records this).

---

## Section 6 - API and testing

Endpoint contract:

| Method | Path | Body | Success | Failure |
|--------|------|------|---------|---------|
| GET | /health | none | 200 {"status":"ok","verification_code":"AI-A2-6951"} | - |
| GET | /model-info | none | 200 with model names, features, artifact count | - |
| POST | /predict | JSON with 7 features | 200 with prediction block | 422 Pydantic errors on missing/wrong/range |

Valid example:

    POST /predict
    {"rainfall_mm":950,"avg_temp_c":19.5,"soil_moisture_pct":55,
     "fertilizer_kg":120,"field_size_ha":2.0,"season":"A","cooperative_support":1}
    -> 200 {"verification_code":"AI-A2-6951","prediction":{
            "yield_tons":6.6,"high_risk":0,
            "high_risk_probability":0.0969,"cluster":4}}

Invalid example (range):

    POST /predict
    {..., "rainfall_mm":5000, ...}
    -> 422 {"detail":[{"type":"less_than_equal",
       "loc":["body","rainfall_mm"],
       "msg":"Input should be less than or equal to 1400"}]}

Invalid example (missing field):

    POST /predict with no "season"
    -> 422 {"detail":[{"type":"missing","loc":["body","season"]}]}

Test summary: pytest -q -> 21 passed. Coverage:

- test_schema.py - 6 tests: valid, missing, wrong type, range, bad season,
  raise_if_bad
- test_predict.py - 3 tests: CLI valid, CLI invalid exit code, direct
  function call
- test_reproducibility.py - 3 tests: current fingerprint matches,
  regeneration reproduces fingerprint, meta.json agrees
- test_api.py - 5 tests: /health, /model-info, valid predict, invalid range,
  invalid missing
- test_ml_pipeline.py - 4 tests: no-leakage assertion, leakage guard raises,
  artifacts load, split determinism

Failure behaviour: schema violations raise SchemaError; CLI exits code 1;
API returns HTTP 422 with Pydantic detail. No model prediction is performed
on invalid input.

---

## Section 7 - Model card, responsible AI, and reflection

Intended use: field-officer decision support in a Musanze potato cooperative,
on synthetic data for coursework.

Limitations:

- Data is synthetic; results do not extrapolate to real farms.
- Cluster silhouettes are weak because the generator has no inherent
  grouping - treat clusters as descriptive strata, not robust segments.
- Small test set (n=192).
- Class imbalance (28 percent positive) means accuracy is misleading; F1 and
  recall are the correct headline metrics.

Risks and mitigations:

- Risk: model output is misinterpreted as authoritative. Mitigation: every
  response includes high_risk_probability, not just a hard label; the README
  and evidence/AI_USE.md state human-review requirement.
- Risk: synthetic-to-real distribution shift degrades accuracy silently.
  Mitigation: the API exposes /model-info so downstream applications know
  which model version they are calling.
- Risk: missing data changes a borderline prediction. Mitigation: the
  misclassified.csv analysis demonstrates this concretely; a real system
  should surface confidence intervals and imputation indicators.

Prohibited use:

- Must never determine access to finance, insurance, or public services.
- Must never replace an agronomist's judgement.
- Must never be deployed on real farm data without retraining and field
  validation.

Human oversight:

- All high-risk flags must be reviewed by a qualified field officer before
  any action.
- Cooperative support decisions must remain a human decision informed by the
  model, not made by the model.

Reflection - what I would improve with real data:

1. Replace the synthetic generator with a real historical dataset from the
   cooperative. Even 2-3 seasons of records would give a much stronger
   classifier and materially different cluster separation.
2. Add per-farm time series so yield prediction can use previous-season
   outcomes rather than single-snapshot features.
3. Introduce explicit missingness indicators (is_missing_soil_moisture) so
   the model can distinguish low values from missing values.
4. Add SHAP or permutation importance per prediction, so a field officer can
   see why a particular farm was flagged high-risk.
5. Wrap the API in a small mobile front-end with offline caching, since
   internet may be unreliable in rural Musanze.
6. Add fairness auditing if the deployment includes access decisions - though
   that is explicitly out of scope for this classroom prototype.

End of report.
