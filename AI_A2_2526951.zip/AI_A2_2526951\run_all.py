"""
Single-command orchestrator: regenerate data, retrain all models,
regenerate all artifacts and plots, verify fingerprint and print summary.

Usage:
  python run_all.py --student-id ug2526951@ines.ac.rw --seed 6951
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERIFICATION_CODE = "AI-A2-6951"
STUDENT_ID = "ug2526951@ines.ac.rw"
LLLL = 6951
DATASET_NAME = "AI_A2_2526951"


def _sha256(p):
    h = hashlib.sha256()
    h.update(Path(p).read_bytes())
    return h.hexdigest()


def _run(module):
    print(f"[{VERIFICATION_CODE}] >>> {module}")
    result = subprocess.run(
        [sys.executable, "-m", module],
        cwd=ROOT,
        capture_output=False,
    )
    if result.returncode != 0:
        raise SystemExit(f"[{VERIFICATION_CODE}] FAILED: {module}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()

    if args.student_id != STUDENT_ID:
        raise SystemExit(
            f"[{VERIFICATION_CODE}] Wrong student-id. "
            f"Expected {STUDENT_ID}, got {args.student_id}"
        )
    if args.seed != LLLL:
        raise SystemExit(
            f"[{VERIFICATION_CODE}] Wrong seed. "
            f"Expected {LLLL}, got {args.seed}"
        )

    print(f"[{VERIFICATION_CODE}] ========================================")
    print(f"[{VERIFICATION_CODE}] Musanze Harvest Intelligence Service")
    print(f"[{VERIFICATION_CODE}] Student: {STUDENT_ID}")
    print(f"[{VERIFICATION_CODE}] Verification code: {VERIFICATION_CODE}")
    print(f"[{VERIFICATION_CODE}] Seed: {args.seed}")
    print(f"[{VERIFICATION_CODE}] ========================================")

    # Step 1 — regenerate dataset
    print(f"[{VERIFICATION_CODE}] >>> data/generate_data.py")
    result = subprocess.run(
        [sys.executable, "data/generate_data.py",
         "--student-id", args.student_id, "--seed", str(args.seed)],
        cwd=ROOT,
    )
    if result.returncode != 0:
        raise SystemExit(f"[{VERIFICATION_CODE}] FAILED: data/generate_data.py")

    fp = _sha256(ROOT / "data" / f"{DATASET_NAME}.csv")
    print(f"[{VERIFICATION_CODE}] Fingerprint: {fp}")

    # Step 2-4 — pipeline of ML modules
    for module in ["src.regression", "src.classification", "src.clustering"]:
        _run(module)

    # Step 5 — plots for regression + classification
    print(f"[{VERIFICATION_CODE}] >>> generate residuals + confusion plots")
    plot_script = (
        "from src.prepare import audit_and_prepare;"
        "from src.regression import run_regression;"
        "from src.classification import run_classification;"
        "from src.plots import residuals_plot, confusion_matrix_plot;"
        "p=audit_and_prepare();"
        "r=run_regression(p);"
        "w=r['winner']['estimator'];"
        "residuals_plot(r['yr_te'], w.predict(r['X_te_t']));"
        "c=run_classification(p);"
        "confusion_matrix_plot(c['yc_te'], c['winner']['test_pred']);"
        "print('plots regenerated')"
    )
    subprocess.run([sys.executable, "-c", plot_script], cwd=ROOT, check=True)

    # Final artifact inventory
    artifacts = sorted(p.name for p in (ROOT / "artifacts").iterdir() if p.is_file())
    models = sorted(p.name for p in (ROOT / "models").iterdir() if p.is_file())
    plots = sorted(p.name for p in (ROOT / "artifacts" / "plots").iterdir() if p.is_file())

    print(f"[{VERIFICATION_CODE}] ========================================")
    print(f"[{VERIFICATION_CODE}] ARTIFACTS:")
    for a in artifacts:
        print(f"[{VERIFICATION_CODE}]   artifacts/{a}")
    print(f"[{VERIFICATION_CODE}] PLOTS:")
    for p in plots:
        print(f"[{VERIFICATION_CODE}]   artifacts/plots/{p}")
    print(f"[{VERIFICATION_CODE}] MODELS:")
    for m in models:
        print(f"[{VERIFICATION_CODE}]   models/{m}")
    print(f"[{VERIFICATION_CODE}] ========================================")
    print(f"[{VERIFICATION_CODE}] Final fingerprint: {fp}")
    print(f"[{VERIFICATION_CODE}] DONE. Reproducible run complete.")


if __name__ == "__main__":
    main()