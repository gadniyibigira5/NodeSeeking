"""
Data loading, deduplication, and stratified splitting for
Musanze Harvest Intelligence Service.

Produces a data audit JSON with fingerprint, dedupe evidence, and split sizes.
Exposes the test-set index so downstream modules can attach predictions back
to raw rows for error analysis.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

from src.pipeline import RANDOM_STATE, TEST_SIZE
from src.schema import (
    FEATURE_COLS,
    ID_COL,
    TARGET_CLASSIFICATION,
    TARGET_REGRESSION,
)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "artifacts"
DATASET_NAME = "AI_A2_2526951"


def _sha256(path):
    h = hashlib.sha256()
    h.update(Path(path).read_bytes())
    return h.hexdigest()


def load_raw():
    csv = DATA_DIR / f"{DATASET_NAME}.csv"
    if not csv.exists():
        raise FileNotFoundError(
            f"Dataset missing at {csv}. Run data/generate_data.py first."
        )
    return pd.read_csv(csv)


def dedupe(df):
    """Return (deduped_df, n_duplicates_removed). Keeps first occurrence."""
    before = len(df)
    deduped = df.drop_duplicates(
        subset=[c for c in df.columns if c != ID_COL]
    ).reset_index(drop=True)
    return deduped, before - len(deduped)


def split(df):
    """Stratified split on classification target for balance."""
    X = df[FEATURE_COLS].copy()
    y_reg = df[TARGET_REGRESSION].copy()
    y_cls = df[TARGET_CLASSIFICATION].copy()

    idx_all = df.index.to_numpy()
    (
        X_tr, X_te,
        yr_tr, yr_te,
        yc_tr, yc_te,
        idx_tr, idx_te,
    ) = train_test_split(
        X, y_reg, y_cls, idx_all,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y_cls,
    )
    return X_tr, X_te, yr_tr, yr_te, yc_tr, yc_te, idx_tr, idx_te


def audit_and_prepare():
    raw = load_raw()
    deduped, n_dup_removed = dedupe(raw)
    X_tr, X_te, yr_tr, yr_te, yc_tr, yc_te, idx_tr, idx_te = split(deduped)

    audit = {
        "verification_code": "AI-A2-6951",
        "student_id": "ug2526951@ines.ac.rw",
        "dataset_path": str(DATA_DIR / f"{DATASET_NAME}.csv"),
        "sha256": _sha256(DATA_DIR / f"{DATASET_NAME}.csv"),
        "n_rows_raw": int(len(raw)),
        "n_missing_cells_raw": int(raw[FEATURE_COLS].isna().sum().sum()),
        "n_duplicate_rows_removed": int(n_dup_removed),
        "n_rows_clean": int(len(deduped)),
        "n_train": int(len(X_tr)),
        "n_test": int(len(X_te)),
        "train_class_balance": {
            "high_risk_0": int((yc_tr == 0).sum()),
            "high_risk_1": int((yc_tr == 1).sum()),
        },
        "test_class_balance": {
            "high_risk_0": int((yc_te == 0).sum()),
            "high_risk_1": int((yc_te == 1).sum()),
        },
        "target_regression_stats": {
            "mean": float(yr_tr.mean()),
            "std": float(yr_tr.std()),
            "min": float(yr_tr.min()),
            "max": float(yr_tr.max()),
        },
    }

    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    (ARTIFACT_DIR / "data_audit.json").write_text(json.dumps(audit, indent=2))
    print(f"[AI-A2-6951] Data audit written: artifacts/data_audit.json")

    return {
        "audit": audit,
        "X_tr": X_tr, "X_te": X_te,
        "yr_tr": yr_tr, "yr_te": yr_te,
        "yc_tr": yc_tr, "yc_te": yc_te,
        "test_index": idx_te,
        "clean_df": deduped,
    }