"""
Synthetic dataset generator for Musanze Harvest Intelligence Service.

Deterministic: same seed -> same CSV bytes -> same SHA-256 fingerprint.
Personalization: seed derived from last 4 digits of registration number.

Registration: 25/26951  ->  LLLL = 6951  ->  verification code AI-A2-6951
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

# ---------- Personalization constants ----------
STUDENT_ID = "ug2526951@ines.ac.rw"
LLLL = 6951
VERIFICATION_CODE = "AI-A2-6951"
DEFAULT_SEED = LLLL
DEFAULT_N_ROWS = 500 + LLLL % 500          # 500..999, unique per student
DATASET_NAME = "AI_A2_2526951"

# ---------- Missing/duplicate injection rates ----------
MISSING_RATE = 0.03                        # 3% NaNs sprinkled across features
DUPLICATE_ROWS = 8                         # exact-duplicate rows to append


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def generate(seed: int = DEFAULT_SEED, n_rows: int = DEFAULT_N_ROWS) -> pd.DataFrame:
    """Generate the raw synthetic potato-farm dataset."""
    rng = np.random.default_rng(seed)

    df = pd.DataFrame({
        "rainfall_mm":          rng.uniform(600, 1400, n_rows),
        "avg_temp_c":           rng.uniform(12, 26, n_rows),
        "soil_moisture_pct":    rng.uniform(20, 80, n_rows),
        "fertilizer_kg":        rng.uniform(0, 250, n_rows),
        "field_size_ha":        rng.uniform(0.2, 4.0, n_rows),
        "season":               rng.choice(["A", "B"], size=n_rows),
        "cooperative_support":  rng.integers(0, 2, n_rows).astype(int),
    })

    # ---- Derived targets (deterministic formula + noise) ----
    season_effect = np.where(df["season"] == "A", 0.8, -0.3)
    base_yield = (
        0.0022 * df["rainfall_mm"]
        + 0.04   * df["avg_temp_c"]
        + 0.012  * df["soil_moisture_pct"]
        + 0.006  * df["fertilizer_kg"]
        + 1.4    * df["field_size_ha"]
        + 0.25   * df["cooperative_support"]
        + season_effect
        - 1.5
    )
    noise = rng.normal(0, 0.35, n_rows)
    df["yield_tons"] = np.clip(base_yield + noise, 0.05, None).round(3)
    df["yield_per_hectare"] = (df["yield_tons"] / df["field_size_ha"]).round(3)

    risk_score = (
        -1.2 * df["yield_per_hectare"]
        - 0.0015 * df["rainfall_mm"]
        - 0.01  * df["soil_moisture_pct"]
        - 0.004 * df["fertilizer_kg"]
        + rng.normal(0, 0.6, n_rows)
    )
    threshold = np.quantile(risk_score, 0.72)
    df["high_risk"] = (risk_score > threshold).astype(int)

    # ---- Deliberate data-quality issues ----
    feature_cols = ["rainfall_mm", "avg_temp_c", "soil_moisture_pct",
                    "fertilizer_kg", "field_size_ha"]
    mask = rng.random((n_rows, len(feature_cols))) < MISSING_RATE
    for j, col in enumerate(feature_cols):
        df.loc[mask[:, j], col] = np.nan

    # Append duplicate rows (exact copies of existing rows)
    dup_idx = rng.choice(n_rows, size=DUPLICATE_ROWS, replace=False)
    df = pd.concat([df, df.iloc[dup_idx]], ignore_index=True)

    # Stable row id (1-indexed, set BEFORE shuffle)
    df.insert(0, "farm_id", np.arange(1, len(df) + 1))

    # Shuffle deterministically so duplicates aren't all at the bottom
    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    df["farm_id"] = np.arange(1, len(df) + 1)

    return df


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--student-id", default=STUDENT_ID)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    args = parser.parse_args()

    if args.student_id != STUDENT_ID:
        raise SystemExit(
            f"[FATAL] Wrong student ID: {args.student_id}. "
            f"Expected {STUDENT_ID}."
        )

    out_path = Path(__file__).resolve().parent / f"{DATASET_NAME}.csv"
    df = generate(seed=args.seed)

    df.to_csv(out_path, index=False, float_format="%.6f")
    fingerprint = _sha256(out_path)

    meta = {
        "student_id": STUDENT_ID,
        "verification_code": VERIFICATION_CODE,
        "seed": args.seed,
        "n_rows_including_duplicates": int(len(df)),
        "n_missing_values": int(df.isna().sum().sum()),
        "n_duplicate_rows": int(df.duplicated(subset=[c for c in df.columns
                                                    if c != "farm_id"]).sum()),
        "sha256": fingerprint,
        "path": str(out_path),
    }
    meta_path = out_path.with_suffix(".meta.json")
    meta_path.write_text(json.dumps(meta, indent=2))

    print(f"[{VERIFICATION_CODE}] Dataset written: {out_path}")
    print(f"[{VERIFICATION_CODE}] Rows: {meta['n_rows_including_duplicates']}")
    print(f"[{VERIFICATION_CODE}] Missing cells: {meta['n_missing_values']}")
    print(f"[{VERIFICATION_CODE}] Duplicate rows: {meta['n_duplicate_rows']}")
    print(f"[{VERIFICATION_CODE}] SHA-256: {fingerprint}")


if __name__ == "__main__":
    main()