"""Pytest fixtures: dataset, models, API client, known fingerprint."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent.parent
DATASET = ROOT / "data" / "AI_A2_2526951.csv"
FINGERPRINT = "a0e540df62a7896394d3ace7e3298f1223c427f491caee3e3f48f6fad27b8895"

VALID_RECORD = {
    "rainfall_mm": 950.0,
    "avg_temp_c": 19.5,
    "soil_moisture_pct": 55.0,
    "fertilizer_kg": 120.0,
    "field_size_ha": 2.0,
    "season": "A",
    "cooperative_support": 1,
}


@pytest.fixture(scope="session")
def valid_record():
    return dict(VALID_RECORD)


@pytest.fixture(scope="session")
def known_fingerprint():
    return FINGERPRINT


@pytest.fixture(scope="session")
def dataset_path():
    return DATASET


@pytest.fixture(scope="session")
def api_client():
    from app import app
    with TestClient(app) as client:
        yield client


@pytest.fixture(scope="session")
def predict_module():
    import predict
    return predict