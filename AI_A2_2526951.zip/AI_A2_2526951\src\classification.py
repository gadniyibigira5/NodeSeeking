"""
Classification models for high_risk prediction.

Baseline: DummyClassifier(strategy="prior")
Candidates:
  1) LogisticRegression(class_weight="balanced")
  2) RandomForestClassifier(class_weight="balanced")

Metrics: precision, recall, F1, ROC-AUC, confusion matrix, per-class report.
Selection rule: highest test F1 on class 1 (high_risk), tie-break ROC-AUC.
Also saves top misclassified test rows to artifacts/misclassified.csv.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from src.pipeline import RANDOM_STATE, fit_transform_train
from src.schema import TARGET_CLASSIFICATION
from src.prepare import ARTIFACT_DIR, audit_and_prepare

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"


def _score(y_true, y_pred, y_proba):
    return {
        "precision_class1": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall_class1": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_class1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, y_proba)) if len(set(y_true)) > 1 else None,
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "report": classification_report(y_true, y_pred, output_dict=True, zero_division=0),
    }


def _train_one(name, estimator, X_tr_t, yc_tr, X_te_t, yc_te):
    estimator.fit(X_tr_t, yc_tr)
    tr_pred = estimator.predict(X_tr_t)
    te_pred = estimator.predict(X_te_t)

    def _proba(est, X):
        if hasattr(est, "predict_proba"):
            return est.predict_proba(X)[:, 1]
        return est.decision_function(X)

    tr_proba = _proba(estimator, X_tr_t)
    te_proba = _proba(estimator, X_te_t)
    return {
        "name": name,
        "train": _score(yc_tr, tr_pred, tr_proba),
        "test": _score(yc_te, te_pred, te_proba),
        "estimator": estimator,
        "test_pred": te_pred,
        "test_proba": te_proba,
    }


def run_classification(prepared=None):
    if prepared is None:
        prepared = audit_and_prepare()

    X_tr, X_te = prepared["X_tr"], prepared["X_te"]
    yc_tr, yc_te = prepared["yc_tr"], prepared["yc_te"]

    pre, X_tr_t = fit_transform_train("classification", X_tr)
    X_te_t = pre.transform(X_te)

    baseline = _train_one("DummyClassifier(prior)",
                          DummyClassifier(strategy="prior"),
                          X_tr_t, yc_tr, X_te_t, yc_te)
    logreg = _train_one("LogisticRegression(balanced)",
                        LogisticRegression(max_iter=1000, class_weight="balanced",
                                           random_state=RANDOM_STATE),
                        X_tr_t, yc_tr, X_te_t, yc_te)
    rf = _train_one("RandomForestClassifier(balanced)",
                    RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                           random_state=RANDOM_STATE, n_jobs=-1),
                    X_tr_t, yc_tr, X_te_t, yc_te)

    candidates = [logreg, rf]
    winner = max(
        candidates,
        key=lambda c: (c["test"]["f1_class1"], c["test"]["roc_auc"] or 0.0),
    )

    metrics = {
        "verification_code": "AI-A2-6951",
        "target": TARGET_CLASSIFICATION,
        "selection_rule": "Highest test F1 on class 1 (high_risk); tie-break ROC-AUC.",
        "baseline": {
            "name": baseline["name"],
            "train": baseline["train"],
            "test": baseline["test"],
        },
        "candidates": [
            {"name": c["name"], "train": c["train"], "test": c["test"]}
            for c in candidates
        ],
        "selected_model": winner["name"],
        "selection_reason": (
            f"F1(class1)={winner['test']['f1_class1']:.4f}, "
            f"ROC-AUC={winner['test']['roc_auc']:.4f} on test set; "
            f"baseline F1(class1)={baseline['test']['f1_class1']:.4f}."
        ),
    }

    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    (ARTIFACT_DIR / "classification_metrics.json").write_text(json.dumps(metrics, indent=2))

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pre, MODEL_DIR / "classification_preprocessor.joblib")
    joblib.dump(winner["estimator"], MODEL_DIR / "classification_model.joblib")
    joblib.dump(baseline["estimator"], MODEL_DIR / "classification_baseline.joblib")

    # Misclassified rows for report evidence
    clean = prepared["clean_df"]
    idx_test = prepared.get("test_index")
    if idx_test is not None:
        Xte_rows = clean.loc[idx_test].reset_index(drop=True)
    else:
        Xte_rows = pd.DataFrame({"note": ["test_index not tracked"]})

    mask = np.asarray(winner["test_pred"]) != np.asarray(yc_te)
    if mask.any() and idx_test is not None:
        mis = Xte_rows.loc[mask].copy()
        mis["actual_high_risk"] = np.asarray(yc_te)[mask]
        mis["predicted_high_risk"] = np.asarray(winner["test_pred"])[mask]
        mis["probability_high_risk"] = np.asarray(winner["test_proba"])[mask]
        mis["abs_error_prob"] = np.abs(mis["actual_high_risk"] - mis["probability_high_risk"])
        mis = mis.sort_values("abs_error_prob", ascending=False).head(10)
        mis.to_csv(ARTIFACT_DIR / "misclassified.csv", index=False)

    print(f"[AI-A2-6951] Classification metrics -> artifacts/classification_metrics.json")
    print(f"[AI-A2-6951] Selected: {winner['name']}")
    print(f"[AI-A2-6951]   baseline F1(class1): {baseline['test']['f1_class1']:.4f}")
    for c in candidates:
        print(f"[AI-A2-6951]   {c['name']} F1: {c['test']['f1_class1']:.4f}  "
              f"ROC-AUC: {c['test']['roc_auc']:.4f}  "
              f"precision: {c['test']['precision_class1']:.4f}  "
              f"recall: {c['test']['recall_class1']:.4f}")

    return {"metrics": metrics, "winner": winner, "baseline": baseline,
            "preprocessor": pre, "X_te_t": X_te_t, "yc_te": yc_te}


if __name__ == "__main__":
    run_classification()