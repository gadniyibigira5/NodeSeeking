"""
Regression models: baseline + 2 candidates, MAE / RMSE / R2, selection rule.

Baseline: DummyRegressor(strategy="mean")
Candidates:
  1) Ridge                - linear, handles multicollinearity
  2) RandomForestRegressor - non-linear, robust to outliers

Selection rule: pick the candidate with the lowest MAE on the test set.
Random seed locked to 6951 everywhere.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.pipeline import RANDOM_STATE, fit_transform_train
from src.schema import TARGET_REGRESSION
from src.prepare import ARTIFACT_DIR, audit_and_prepare

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"


def _metrics(y_true, y_pred):
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "r2": float(r2_score(y_true, y_pred)),
    }


def _train_one(name, estimator, X_tr_t, yr_tr, X_te_t, yr_te):
    estimator.fit(X_tr_t, yr_tr)
    train_pred = estimator.predict(X_tr_t)
    test_pred = estimator.predict(X_te_t)
    return {
        "name": name,
        "train": _metrics(yr_tr, train_pred),
        "test": _metrics(yr_te, test_pred),
        "estimator": estimator,
    }


def run_regression(prepared=None):
    if prepared is None:
        prepared = audit_and_prepare()

    X_tr, X_te = prepared["X_tr"], prepared["X_te"]
    yr_tr, yr_te = prepared["yr_tr"], prepared["yr_te"]

    pre, X_tr_t = fit_transform_train("regression", X_tr)
    X_te_t = pre.transform(X_te)

    baseline = _train_one("DummyRegressor(mean)", DummyRegressor(strategy="mean"),
                          X_tr_t, yr_tr, X_te_t, yr_te)
    ridge = _train_one("Ridge(alpha=1.0)", Ridge(alpha=1.0, random_state=RANDOM_STATE),
                       X_tr_t, yr_tr, X_te_t, yr_te)
    rf = _train_one("RandomForestRegressor(n=300)", 
                    RandomForestRegressor(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1),
                    X_tr_t, yr_tr, X_te_t, yr_te)

    candidates = [ridge, rf]
    winner = min(candidates, key=lambda r: r["test"]["mae"])

    metrics = {
        "verification_code": "AI-A2-6951",
        "target": TARGET_REGRESSION,
        "baseline": {
            "name": baseline["name"],
            "train": baseline["train"],
            "test": baseline["test"],
        },
        "candidates": [
            {"name": c["name"], "train": c["train"], "test": c["test"]}
            for c in candidates
        ],
        "selected_model": winner["name"],
        "selection_reason": (
            f"Lowest test MAE among candidates "
            f"({winner['test']['mae']:.4f}) vs baseline "
            f"({baseline['test']['mae']:.4f})."
        ),
    }

    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    (ARTIFACT_DIR / "regression_metrics.json").write_text(json.dumps(metrics, indent=2))

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pre, MODEL_DIR / "regression_preprocessor.joblib")
    joblib.dump(winner["estimator"], MODEL_DIR / "regression_model.joblib")
    joblib.dump(baseline["estimator"], MODEL_DIR / "regression_baseline.joblib")

    print(f"[AI-A2-6951] Regression metrics -> artifacts/regression_metrics.json")
    print(f"[AI-A2-6951] Selected: {winner['name']}")
    print(f"[AI-A2-6951]   baseline test MAE: {baseline['test']['mae']:.4f}")
    for c in candidates:
        print(f"[AI-A2-6951]   {c['name']} test MAE: {c['test']['mae']:.4f}  R2: {c['test']['r2']:.4f}")

    return {"metrics": metrics, "winner": winner, "baseline": baseline, "preprocessor": pre,
            "X_te_t": X_te_t, "yr_te": yr_te}


if __name__ == "__main__":
    run_regression()