from __future__ import annotations

from dataclasses import dataclass

ID_COL = "farm_id"

FEATURE_COLS_NUMERIC = [
    "rainfall_mm",
    "avg_temp_c",
    "soil_moisture_pct",
    "fertilizer_kg",
    "field_size_ha",
]
FEATURE_COLS_CATEGORICAL = ["season"]
FEATURE_COLS_BINARY = ["cooperative_support"]
FEATURE_COLS = FEATURE_COLS_NUMERIC + FEATURE_COLS_CATEGORICAL + FEATURE_COLS_BINARY

TARGET_REGRESSION = "yield_tons"
TARGET_CLASSIFICATION = "high_risk"
AUXILIARY_COL = "yield_per_hectare"

LEAKY_COLUMNS = {TARGET_REGRESSION, AUXILIARY_COL, TARGET_CLASSIFICATION}

RANGE_RULES = {
    "rainfall_mm":         (600.0, 1400.0),
    "avg_temp_c":          (12.0,  26.0),
    "soil_moisture_pct":   (20.0,  80.0),
    "fertilizer_kg":       (0.0,   250.0),
    "field_size_ha":       (0.2,   4.0),
    "cooperative_support": (0.0,   1.0),
}

SEASON_ALLOWED = ("A", "B")


class SchemaError(ValueError):
    """Raised when an incoming record violates the data contract."""


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    errors: list

    def raise_if_bad(self) -> None:
        if not self.ok:
            raise SchemaError("; ".join(self.errors))


def validate_record(record):
    errors = []
    for col in FEATURE_COLS:
        if col not in record:
            errors.append(f"missing field '{col}'")
    if errors:
        return ValidationResult(ok=False, errors=errors)
    for col, (lo, hi) in RANGE_RULES.items():
        value = record[col]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append(f"'{col}' must be a number, got {type(value).__name__}")
            continue
        if not (lo <= float(value) <= hi):
            errors.append(f"'{col}' = {value} out of range [{lo}, {hi}]")
    season = record["season"]
    if season not in SEASON_ALLOWED:
        errors.append(f"'season' must be one of {SEASON_ALLOWED}, got {season!r}")
    return ValidationResult(ok=not errors, errors=errors)


def check_no_leakage(feature_columns):
    bad = set(feature_columns) & LEAKY_COLUMNS
    if bad:
        raise SchemaError(f"Leaky columns in feature set: {sorted(bad)}")