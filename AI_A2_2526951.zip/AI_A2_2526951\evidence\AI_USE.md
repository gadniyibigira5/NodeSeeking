# AI Use Disclosure

Student: Gad Niyibigira
Registration: 25/26951
Verification code: AI-A2-6951

## Tools used
- AI assistant (Claude): used to draft and refine Python code structure,
  scikit-learn pipeline patterns, and report sections.
- No other AI tools were used.

## What was authored with AI assistance
- Initial scaffolding of src/ modules and the FastAPI service
- Sample code for sklearn ColumnTransformer, Pipeline, and metrics calls
- Structural templates for the README, report sections, and this disclosure

## What I verified
- Ran every command, inspected every output, fixed every runtime error
- Understood and can explain every module: schema, pipeline, prepare,
  regression, classification, clustering, predict, app, tests
- Verified the reproducibility fingerprint a0e540df...
- Verified model selection rationale: Ridge on MAE, LogReg on F1, KMeans on
  silhouette
- Reviewed and edited every sentence in the report so it matches the actual
  generated JSON

## Rules respected
- No target leakage: yield_tons, yield_per_hectare, high_risk are excluded
  from every feature list (LEAKY_COLUMNS in src/schema.py).
- Preprocessing is fitted only on training data (fit_transform_train).
- All random states are fixed (RANDOM_STATE = 6951).
- Reproducibility is enforced by SHA-256 and verified with pytest (21 tests).
- Submission is my own work: I typed, ran, debugged and can modify any line
  live. AI-assisted drafting is disclosed here as the assignment permits.

## Human oversight statement
This service is a classroom prototype. It must not replace an agronomist and
must never determine access to finance, insurance, or public services. All
high-risk flags must be reviewed by a qualified field officer before any
decision is taken. Model outputs are advisory, not authoritative.