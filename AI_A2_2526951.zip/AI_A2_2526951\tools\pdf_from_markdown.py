"""Render a markdown-ish text file to a multi-page PDF using matplotlib.

Reads UTF-8, UTF-8-sig (BOM), UTF-16 (BOM), and Latin-1 as fallback.
No extra dependencies -- matplotlib is already installed.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages


def _read_any(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "utf-16", "utf-16-le", "utf-16-be", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def render(md_path: Path, pdf_path: Path, title: str = "Document") -> None:
    text = _read_any(md_path)
    lines = text.splitlines()
    lines_per_page = 45
    pages = [lines[i:i + lines_per_page] for i in range(0, len(lines), lines_per_page)] or [[""]]

    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    with PdfPages(pdf_path) as pdf:
        for page_num, page_lines in enumerate(pages, start=1):
            fig = plt.figure(figsize=(8.5, 11))
            ax = fig.add_axes([0.06, 0.06, 0.88, 0.88])
            ax.axis("off")
            body = "\n".join(page_lines)
            ax.text(0.0, 1.0, body, ha="left", va="top",
                    family="monospace", fontsize=8,
                    transform=ax.transAxes, wrap=True)
            ax.text(0.0, -0.03,
                    f"{title}  |  page {page_num}/{len(pages)}  |  AI-A2-6951",
                    ha="left", va="top", fontsize=7, color="#555",
                    transform=ax.transAxes)
            pdf.savefig(fig, bbox_inches="tight", pad_inches=0.4)
            plt.close(fig)
    print(f"PDF written: {pdf_path}  ({len(pages)} page(s))")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("md")
    parser.add_argument("pdf")
    parser.add_argument("--title", default="Document")
    args = parser.parse_args()
    render(Path(args.md), Path(args.pdf), title=args.title)


if __name__ == "__main__":
    main()