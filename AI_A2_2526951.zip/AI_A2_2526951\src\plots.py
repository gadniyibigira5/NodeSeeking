"""
Plot generation: residuals, confusion matrix, clusters.

All plots are saved as PNGs into artifacts/plots/.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

PLOT_DIR = Path(__file__).resolve().parent.parent / "artifacts" / "plots"


def residuals_plot(y_true, y_pred, title="Residuals"):
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    residual = np.asarray(y_true) - np.asarray(y_pred)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    axes[0].scatter(y_pred, residual, alpha=0.6, edgecolor="k", linewidth=0.3)
    axes[0].axhline(0, color="red", linestyle="--")
    axes[0].set_xlabel("Predicted yield_tons")
    axes[0].set_ylabel("Residual")
    axes[0].set_title(f"{title}: Predicted vs Residual")

    axes[1].hist(residual, bins=30, edgecolor="k", alpha=0.75)
    axes[1].set_xlabel("Residual")
    axes[1].set_ylabel("Count")
    axes[1].set_title(f"{title}: Distribution")

    fig.tight_layout()
    out = PLOT_DIR / "residuals.png"
    fig.savefig(out, dpi=140)
    plt.close(fig)
    return out


def confusion_matrix_plot(y_true, y_pred, title="Confusion Matrix"):
    from sklearn.metrics import confusion_matrix
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=["low_risk (0)", "high_risk (1)"],
                yticklabels=["low_risk (0)", "high_risk (1)"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(title)
    fig.tight_layout()
    out = PLOT_DIR / "confusion_matrix.png"
    fig.savefig(out, dpi=140)
    plt.close(fig)
    return out


def clusters_plot(X_2d, labels, centers_2d=None, title="Clusters (PCA 2D)"):
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    scatter = ax.scatter(X_2d[:, 0], X_2d[:, 1], c=labels, cmap="tab10", alpha=0.7, edgecolor="k", linewidth=0.3)
    if centers_2d is not None:
        ax.scatter(centers_2d[:, 0], centers_2d[:, 1], marker="X", s=200, c="black", label="Centroids")
        ax.legend()
    ax.set_xlabel("PC 1")
    ax.set_ylabel("PC 2")
    ax.set_title(title)
    fig.tight_layout()
    out = PLOT_DIR / "clusters.png"
    fig.savefig(out, dpi=140)
    plt.close(fig)
    return out