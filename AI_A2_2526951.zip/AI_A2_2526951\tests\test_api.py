"""FastAPI tests: health, model-info, valid predict, invalid predict."""
from __future__ import annotations


def test_health(api_client):
    r = api_client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["verification_code"] == "AI-A2-6951"


def test_model_info(api_client):
    r = api_client.get("/model-info")
    assert r.status_code == 200
    body = r.json()
    assert body["verification_code"] == "AI-A2-6951"
    assert "regression" in body["models"]
    assert "classification" in body["models"]
    assert "clustering" in body["models"]


def test_predict_valid(api_client, valid_record):
    r = api_client.post("/predict", json=valid_record)
    assert r.status_code == 200
    body = r.json()
    assert body["verification_code"] == "AI-A2-6951"
    pred = body["prediction"]
    assert isinstance(pred["yield_tons"], float)
    assert pred["high_risk"] in (0, 1)
    assert 0.0 <= pred["high_risk_probability"] <= 1.0
    assert isinstance(pred["cluster"], int)


def test_predict_invalid_range(api_client, valid_record):
    bad = dict(valid_record)
    bad["rainfall_mm"] = 5000.0
    r = api_client.post("/predict", json=bad)
    assert r.status_code == 422
    detail = r.json()["detail"]
    assert any("rainfall_mm" in str(d) for d in detail)


def test_predict_invalid_missing(api_client, valid_record):
    bad = dict(valid_record)
    del bad["season"]
    r = api_client.post("/predict", json=bad)
    assert r.status_code == 422