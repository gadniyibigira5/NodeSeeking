"""Schema validation tests: valid, missing, wrong type, range error."""
from __future__ import annotations

import pytest

from src.schema import SchemaError, validate_record


def test_valid_record_passes(valid_record):
    r = validate_record(valid_record)
    assert r.ok, f"Expected valid, got errors: {r.errors}"


def test_missing_field_fails(valid_record):
    bad = dict(valid_record)
    del bad["season"]
    r = validate_record(bad)
    assert not r.ok
    assert any("season" in e and "missing" in e for e in r.errors)


def test_wrong_type_fails(valid_record):
    bad = dict(valid_record)
    bad["rainfall_mm"] = "lots"
    r = validate_record(bad)
    assert not r.ok
    assert any("rainfall_mm" in e and "number" in e for e in r.errors)


def test_out_of_range_fails(valid_record):
    bad = dict(valid_record)
    bad["rainfall_mm"] = 5000.0
    r = validate_record(bad)
    assert not r.ok
    assert any("rainfall_mm" in e and "range" in e for e in r.errors)


def test_bad_season_fails(valid_record):
    bad = dict(valid_record)
    bad["season"] = "C"
    r = validate_record(bad)
    assert not r.ok
    assert any("season" in e for e in r.errors)


def test_raise_if_bad_raises(valid_record):
    bad = dict(valid_record)
    bad["avg_temp_c"] = 100.0
    with pytest.raises(SchemaError):
        validate_record(bad).raise_if_bad()