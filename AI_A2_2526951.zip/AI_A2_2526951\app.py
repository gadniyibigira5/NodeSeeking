"""
FastAPI service for Musanze Harvest Intelligence Service.

Endpoints:
  GET  /health      -> liveness + verification code
  GET  /model-info  -> model names, verification code, artifact status
  POST /predict     -> validated prediction (yield, high_risk, cluster)
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from src.schema import (
    FEATURE_COLS,
    SchemaError,
    validate_record,
)

VERIFICATION_CODE = "AI-A2-6951"
MODEL_DIR = Path(__file__).resolve().parent / "models"

app = FastAPI(
    title="Musanze Harvest Intelligence Service",
    version="1.0.0",
    description=f"Verification: {VERIFICATION_CODE}",
)


class PredictRequest(BaseModel):
    rainfall_mm: float = Field(..., ge=600, le=1400)
    avg_temp_c: float = Field(..., ge=12, le=26)
    soil_moisture_pct: float = Field(..., ge=20, le=80)
    fertilizer_kg: float = Field(..., ge=0, le=250)
    field_size_ha: float = Field(..., ge=0.2, le=4.0)
    season: str = Field(..., pattern="^[AB]$")
    cooperative_support: int = Field(..., ge=0, le=1)


_models = {}


def _ensure_loaded():
    if _models:
        return
    needed = [
        "regression_preprocessor.joblib", "regression_model.joblib",
        "classification_preprocessor.joblib", "classification_model.joblib",
        "clustering_preprocessor.joblib", "clustering_model.joblib",
    ]
    for name in needed:
        p = MODEL_DIR / name
        if not p.exists():
            raise HTTPException(
                status_code=503,
                detail=f"Model artifact missing: {name}. Run run_all.py.",
            )
        _models[name] = joblib.load(p)


@app.get("/health")
def health():
    return {"status": "ok", "verification_code": VERIFICATION_CODE}


@app.get("/model-info")
def model_info():
    _ensure_loaded()
    return {
        "verification_code": VERIFICATION_CODE,
        "student_id": "ug2526951@ines.ac.rw",
        "models": {
            "regression": "Ridge(alpha=1.0)",
            "classification": "LogisticRegression(balanced)",
            "clustering": "KMeans(K=6)",
        },
        "features": FEATURE_COLS,
        "artifact_count": len(_models),
    }


@app.post("/predict")
def predict(req: PredictRequest):
    _ensure_loaded()
    record = req.model_dump()

    result = validate_record(record)
    if not result.ok:
        raise HTTPException(status_code=422, detail=result.errors)

    X = pd.DataFrame([{c: record[c] for c in FEATURE_COLS}])

    yield_pred = float(
        _models["regression_model.joblib"].predict(
            _models["regression_preprocessor.joblib"].transform(X)
        )[0]
    )
    proba = float(
        _models["classification_model.joblib"].predict_proba(
            _models["classification_preprocessor.joblib"].transform(X)
        )[0, 1]
    )
    cluster = int(
        _models["clustering_model.joblib"].predict(
            _models["clustering_preprocessor.joblib"].transform(X)
        )[0]
    )

    return {
        "verification_code": VERIFICATION_CODE,
        "prediction": {
            "yield_tons": round(yield_pred, 3),
            "high_risk": int(proba >= 0.5),
            "high_risk_probability": round(proba, 4),
            "cluster": cluster,
        },
        "input": record,
    }