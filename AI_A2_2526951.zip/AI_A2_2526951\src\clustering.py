"""
Clustering: compare K=2..6, select by silhouette, profile each cluster.

Rules honored:
  * Only FEATURE_COLS used (no yield_tons, no high_risk, no yield_per_hectare).
  * Silhouette computed on the FULL transformed clean set (no target needed).
  * Selection: highest silhouette in K=2..6.
  * Profiles: mean of each numeric feature + mode of season + mean of cooperative flag.
  * 2D visualization via PCA.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

from src.pipeline import RANDOM_STATE, build_preprocessor
from src.prepare import ARTIFACT_DIR, audit_and_prepare
from src.schema import (
    FEATURE_COLS,
    FEATURE_COLS_CATEGORICAL,
    FEATURE_COLS_NUMERIC,
    FEATURE_COLS_BINARY,
)
from src.plots import clusters_plot

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
K_RANGE = list(range(2, 7))


def _profile(df_clean, labels):
    """Per-cluster mean of numeric cols + mode of season + mean of cooperative_support."""
    tmp = df_clean[FEATURE_COLS].copy()
    tmp["_cluster"] = labels
    profiles = []
    for k in sorted(tmp["_cluster"].unique()):
        chunk = tmp[tmp["_cluster"] == k]
        row = {"cluster": int(k), "n": int(len(chunk))}
        for col in FEATURE_COLS_NUMERIC:
            row[f"mean_{col}"] = float(chunk[col].mean())
        for col in FEATURE_COLS_CATEGORICAL:
            m = chunk[col].mode()
            row[f"mode_{col}"] = str(m.iloc[0]) if not m.empty else ""
        for col in FEATURE_COLS_BINARY:
            row[f"mean_{col}"] = float(chunk[col].mean())
        profiles.append(row)
    return profiles


def run_clustering(prepared=None):
    if prepared is None:
        prepared = audit_and_prepare()

    clean = prepared["clean_df"]
    X_clean = clean[FEATURE_COLS].copy()

    pre = build_preprocessor("clustering")
    X_t = pre.fit_transform(X_clean)

    scores = []
    fitted = {}
    for k in K_RANGE:
        km = KMeans(n_clusters=k, n_init=10, random_state=RANDOM_STATE)
        labels = km.fit_predict(X_t)
        sil = float(silhouette_score(X_t, labels)) if len(set(labels)) > 1 else -1.0
        scores.append({"k": k, "silhouette": sil, "inertia": float(km.inertia_)})
        fitted[k] = (km, labels)

    best = max(scores, key=lambda s: s["silhouette"])
    best_k = best["k"]
    km_best, labels_best = fitted[best_k]
    profiles = _profile(clean, labels_best)

    pca = PCA(n_components=2, random_state=RANDOM_STATE)
    X_2d = pca.fit_transform(X_t)
    centers_2d = pca.transform(km_best.cluster_centers_)
    plot_path = clusters_plot(X_2d, labels_best, centers_2d=centers_2d,
                              title=f"KMeans clusters (K={best_k}, PCA 2D)")

    report = {
        "verification_code": "AI-A2-6951",
        "features_used": FEATURE_COLS,
        "excluded_targets": ["yield_tons", "yield_per_hectare", "high_risk"],
        "k_scores": scores,
        "selected_k": best_k,
        "selection_rule": "Highest silhouette_score in K=2..6.",
        "selected_silhouette": best["silhouette"],
        "profiles": profiles,
        "pca_explained_variance_ratio": [float(v) for v in pca.explained_variance_ratio_],
        "plot_path": str(plot_path),
    }

    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    (ARTIFACT_DIR / "clustering_report.json").write_text(json.dumps(report, indent=2))

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pre, MODEL_DIR / "clustering_preprocessor.joblib")
    joblib.dump(km_best, MODEL_DIR / "clustering_model.joblib")
    joblib.dump(pca, MODEL_DIR / "clustering_pca.joblib")

    print(f"[AI-A2-6951] Clustering report -> artifacts/clustering_report.json")
    print(f"[AI-A2-6951] K scores (silhouette):")
    for s in scores:
        marker = " <-- selected" if s["k"] == best_k else ""
        print(f"[AI-A2-6951]   K={s['k']}  silhouette={s['silhouette']:.4f}{marker}")
    print(f"[AI-A2-6951] Selected K={best_k}")
    for p in profiles:
        print(f"[AI-A2-6951]   Cluster {p['cluster']}: n={p['n']}, "
              f"rain={p['mean_rainfall_mm']:.0f}mm, "
              f"temp={p['mean_avg_temp_c']:.1f}C, "
              f"soil={p['mean_soil_moisture_pct']:.1f}%, "
              f"fert={p['mean_fertilizer_kg']:.0f}kg, "
              f"size={p['mean_field_size_ha']:.2f}ha, "
              f"season_mode={p['mode_season']}, "
              f"coop={p['mean_cooperative_support']:.2f}")

    return {"report": report, "labels": labels_best, "model": km_best,
            "preprocessor": pre, "X_t": X_t, "plot_path": plot_path}


if __name__ == "__main__":
    run_clustering()