from __future__ import annotations

from pathlib import Path

import joblib
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.schema import (
    FEATURE_COLS_BINARY,
    FEATURE_COLS_CATEGORICAL,
    FEATURE_COLS_NUMERIC,
    check_no_leakage,
)

RANDOM_STATE = 6951
TEST_SIZE = 0.2


def build_preprocessor(task):
    check_no_leakage(FEATURE_COLS_NUMERIC + FEATURE_COLS_CATEGORICAL + FEATURE_COLS_BINARY)

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    binary_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
    ])

    if task == "clustering":
        return ColumnTransformer(
            transformers=[
                ("num", numeric_pipe, FEATURE_COLS_NUMERIC),
                ("cat", categorical_pipe, FEATURE_COLS_CATEGORICAL),
            ],
            remainder="drop",
            verbose_feature_names_out=False,
        )

    return ColumnTransformer(
        transformers=[
            ("num", numeric_pipe, FEATURE_COLS_NUMERIC),
            ("cat", categorical_pipe, FEATURE_COLS_CATEGORICAL),
            ("bin", binary_pipe, FEATURE_COLS_BINARY),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


def fit_transform_train(task, X_train):
    pre = build_preprocessor(task)
    X_train_t = pre.fit_transform(X_train)
    return pre, X_train_t


def transform(pre, X):
    return pre.transform(X)


def save_preprocessor(pre, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pre, path)
    return path


def load_preprocessor(path):
    return joblib.load(Path(path))