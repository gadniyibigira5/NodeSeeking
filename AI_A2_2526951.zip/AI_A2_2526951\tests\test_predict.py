"""CLI prediction tests: valid inference + validation error path."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def test_cli_valid_returns_prediction():
    result = subprocess.run(
        [sys.executable, "predict.py", "--json", "samples/valid.json"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 0, f"stderr: {result.stderr}"
    import json as _json
    payload = _json.loads(result.stdout)
    assert payload["verification_code"] == "AI-A2-6951"
    pred = payload["prediction"]
    assert "yield_tons" in pred
    assert "high_risk" in pred
    assert pred["high_risk"] in (0, 1)


def test_cli_invalid_exits_nonzero():
    result = subprocess.run(
        [sys.executable, "predict.py", "--json", "samples/invalid.json"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode != 0
    assert "rainfall_mm" in (result.stderr + result.stdout)


def test_predict_one_function_direct(valid_record, predict_module):
    out = predict_module.predict_one(valid_record)
    assert out["verification_code"] == "AI-A2-6951"
    assert isinstance(out["prediction"]["yield_tons"], float)
    assert out["prediction"]["high_risk"] in (0, 1)